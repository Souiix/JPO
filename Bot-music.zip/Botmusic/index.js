const Discord = require('discord.js');
const bot = new Discord.Client();
//Paramétrage du prefix pour commander le bot
const PREFIX = "!";

var dispatcher;
//fonction pour que le bot nous signal sont état au lancement
bot.on('ready', function(){
    console.log("I'm Ready !");
});
//Fonction play pour lire la musique.
bot.on('message', message => {
    if(message.content[0] === PREFIX) {
        let splitMessage = message.content.split(" ");
        if(splitMessage[0] === 'play') {
            if(splitMessage.length === 2)
            {
                if(message.member.voiceChannel)
                {
                    //Fonction permettant de rejoindre l'utilisateur dans le channel
                    message.member.voiceChannel.join().then(connection => {
                        dispatcher = connection.playArbitraryInput(splitMessage[1]);

                        dispatcher.on('error', e => {
                            console.log(e);
                        });

                        dispatcher.on('end', e => {
                            dispatcher = undefined;
                            console.log('Fin du son');
                        });
                    }).catch(console.log);
                }
                else
                {
                    sendError(message, "Erreur, vous devez d'abord rejoindre un canal vocal");
                }
            }
            else
                sendError(message, 'Erreur, problème dans les paramètres');
        }
        else if(splitMessage[0] === '!pause'){
             if(dispatcher !== undefined)
                dispatcher.pause();
        }
        else if(splitMessage[0] === '!resume'){
            if(dispatcher !== undefined)
               dispatcher.resume();
       }
    }
});
//Votre Token 
bot.login('...')