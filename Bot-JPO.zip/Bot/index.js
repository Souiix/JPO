const Discord  = require("discord.js");

const YTDL = require("ytdl-core");

//Le TOKEN de votre bot attention il doit rester confidentiel ! Votre bot peut être contrôlé avec le TOKEN
const TOKEN = "...";

//Le prefix pour pouvoir communiquer avec le bot
const PREFIX = "!go ";

//Création de la variable bot
var bot = new Discord.Client();

//Fonction qui permet de signaler la connexion au serveur discord
bot.on("ready", function(){
    console.log("Ready");

});

//Fonction pour recevoir un nouveau connecté
bot.on("guildMemberAdd", function(member){
    member.build.channels.find("name", "general").sendMessage(member.toString() * " Bienvenue au lycée Leatitia Bonaparte pour la journée porte ouverte !");

    member.addRole(member.guild.roles.find("name", "SIO"));

    member.guild.createRole({
        name: member.user.username,
        color: generateHex(),
        permissions: []
    }).then(function(role) {
        member.addRole(role);
    });
});

//La structure if pour le messahe "hello" ou "Hello"
bot.on("message", function(message){
    if (message.author.equals(bot.user)) return;

    if (message.content === "hello" || message.content === "Hello"){
        message.channel.sendMessage("Salut, :) !")
    }

    if (!message.content.startsWith(PREFIX)) return;

    var args = message.content.substring(PREFIX.length).split(" ");

    //La conversation :
    switch (args[0]) {
        case "ping":
            message.channel.sendMessage("Pong!");
            break;
        case "JPO":
            message.channel.sendMessage("Bienvenue à la Journée Porte Ouverte de la spécialité SIO ! Je suis un bot discord programmé en Javascript un language de programmation !");
            message.channel.sendMessage("Pour que je t'explique la filière SIO et ses débouchés en études ou travails tu as juste à me demander '!go SIO' :) !");
            break;
        case "SIO":
            message.channel.sendMessage("Alors le BTS SIO : L'objectif de ce BTS est de former l'élève à développer, à adapter et à maintenir des solutions applicatives. Le BTS Services informatique aux Organisations est un diplôme reconnu par l'état de niveau Bac +2.");
            message.channel.sendMessage("Voici un lien où tu auras toutes les infos supplémentaires : https://www.btsinfo.fr/");
            message.channel.sendMessage("Tu as 2 options à disposition dans ce BTS !! ");
            message.channel.sendMessage("1- SLAM (pour que je t'explique cette option !go SLAM !)");
            message.channel.sendMessage("2- SISR (!go SISR pour une explication !)");
            break;
        case "SLAM":
            message.channel.sendMessage("Alors en SLAM : ");
            message.channel.sendMessage("Tu es formé pendant 2 ans pour devenir développeur ! Tu vas apprendre différents languages comme :");
            message.channel.sendMessage("---> HTML & CSS");
            message.channel.sendMessage("---> SQL");
            message.channel.sendMessage("---> C#");
            message.channel.sendMessage("---> PHP");
            message.channel.sendMessage("---> Python");
            message.channel.sendMessage("---> JavaScript");
            message.channel.sendMessage("---> Script Batch");
            break;
        case "SISR":
            message.channel.sendMessage("Alors en SISR : ");
            message.channel.sendMessage("Tu es formé pendant une période de 2 ans pour devenir technicien réseau ! Tu vas apprendre un tas de choses !");
            message.channel.sendMessage("---> L'Adressages ip !")
            message.channel.sendMessage("---> Le routage !")
            message.channel.sendMessage("Et pleins d'autres choses encore !!")
            break;
        default:
            message.channel.sendMessage("Je ne connais pas cette commande :(");
    }
});
//Pour la connection.
bot.login(TOKEN);